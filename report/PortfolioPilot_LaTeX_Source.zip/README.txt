PortfolioPilot — LaTeX project report

Overleaf
1. New Project > Upload Project: select PortfolioPilot_LaTeX_Source.zip.
2. Set PortfolioPilot_Report.tex as the main document.
3. Select pdfLaTeX and click Recompile.

Local build (from the directory containing the .tex file)
pdflatex PortfolioPilot_Report.tex
pdflatex PortfolioPilot_Report.tex

Keep images/ beside PortfolioPilot_Report.tex. All references are included in
the source; no .bib file or external scripts are required.

Suggested GitHub layout
report/PortfolioPilot_Report.tex
report/PortfolioPilot_Report.pdf
report/images/ (all supplied figures)

The PDF is compiled from the included source. Recorded experimental results
are documented with their repository paths; these experiments were not rerun
as part of report typesetting.
